<div>
    <p class="h5 text-center">
        Tersisa: <strong class="text-primary">{{ $tersisa }}</strong> Mahasiswa
    </p>
</div>
