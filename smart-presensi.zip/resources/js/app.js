require('./bootstrap');
const Turbolinks = require("turbolinks")
Turbolinks.start()