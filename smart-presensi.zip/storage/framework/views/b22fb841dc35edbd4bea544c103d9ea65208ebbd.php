<?php $__env->startSection('title'); ?>
    Welcome
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Halaman Login</h1>
        <a href="<?php echo e(url('/login', [])); ?>">Login</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smart-presensi\resources\views/welcome.blade.php ENDPATH**/ ?>