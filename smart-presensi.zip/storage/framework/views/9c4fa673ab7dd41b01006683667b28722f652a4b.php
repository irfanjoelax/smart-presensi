

<?php $__env->startSection('title'); ?>
    Presensi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Presensi</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dosen.presensi.form', [])->html();
} elseif ($_instance->childHasBeenRendered('rCN3f7U')) {
    $componentId = $_instance->getRenderedChildComponentId('rCN3f7U');
    $componentTag = $_instance->getRenderedChildComponentTagName('rCN3f7U');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rCN3f7U');
} else {
    $response = \Livewire\Livewire::mount('dosen.presensi.form', []);
    $html = $response->html();
    $_instance->logRenderedChild('rCN3f7U', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dosen.presensi.table', [])->html();
} elseif ($_instance->childHasBeenRendered('pP2EFD5')) {
    $componentId = $_instance->getRenderedChildComponentId('pP2EFD5');
    $componentTag = $_instance->getRenderedChildComponentTagName('pP2EFD5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pP2EFD5');
} else {
    $response = \Livewire\Livewire::mount('dosen.presensi.table', []);
    $html = $response->html();
    $_instance->logRenderedChild('pP2EFD5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smart-presensi\resources\views/dosen/presensi.blade.php ENDPATH**/ ?>