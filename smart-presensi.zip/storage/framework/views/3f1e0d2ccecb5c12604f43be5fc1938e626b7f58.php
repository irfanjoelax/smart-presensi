

<?php $__env->startSection('title'); ?>
    Generate QR
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Generate QR</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dosen.generate', [])->html();
} elseif ($_instance->childHasBeenRendered('dsrxaWx')) {
    $componentId = $_instance->getRenderedChildComponentId('dsrxaWx');
    $componentTag = $_instance->getRenderedChildComponentTagName('dsrxaWx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dsrxaWx');
} else {
    $response = \Livewire\Livewire::mount('dosen.generate', []);
    $html = $response->html();
    $_instance->logRenderedChild('dsrxaWx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smart-presensi\resources\views/dosen/generate-qr.blade.php ENDPATH**/ ?>