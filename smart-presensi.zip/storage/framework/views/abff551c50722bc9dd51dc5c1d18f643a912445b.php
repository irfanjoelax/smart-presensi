<div class="row mt-4">
    <?php $__empty_1 = true; $__currentLoopData = $matakuliahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3">
            <div class="card shadow p-3">
                <h5 class="font-weight-bold"><?php echo e($matakuliah->nama); ?></h5>
                <hr>
                <div class="d-flex align-item-center justify-content-between">
                    <div class="d-flex flex-column">
                        <small class="font-weight-bold"><?php echo e($matakuliah->hari); ?></small>
                        <small class="text-muted">Pukul: <?php echo e($matakuliah->jam); ?></small>
                    </div>
                    <div class="d-flex flex-column">
                        <small class="font-weight-bold">Kuota</small>
                        <small class="text-muted"><?php echo e($matakuliah->kuota); ?> Mahasiswa</small>
                    </div>
                </div>
                <div class="d-flex flex-column mt-3">
                    <button type="button" class="btn btn-sm btn-primary mb-2" wire:click="edit(<?php echo e($matakuliah->id); ?>)">
                        <div wire:loading wire:target="edit(<?php echo e($matakuliah->id); ?>)">
                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                        </div>
                        Ubah
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-danger"
                        wire:click="delete(<?php echo e($matakuliah->id); ?>)">
                        <div wire:loading wire:target="delete(<?php echo e($matakuliah->id); ?>)">
                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                        </div>
                        Hapus
                    </button>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="card shadow p-3">
                <h1 class="display-1 mb-3 text-warning">
                    <i class="fas fa-exclamation-circle"></i>
                </h1>
                <h3 class="font-weight-bold">
                    Mata Kuliah Bapak/Ibu Dosen masih kosong
                </h3>
                <h6 class="text-muted">
                    Silakan Ditambahkan dulu ya..
                </h6>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-12 mt-2">
        <?php echo e($matakuliahs->links()); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\smart-presensi\resources\views/livewire/dosen/matakuliah/index.blade.php ENDPATH**/ ?>