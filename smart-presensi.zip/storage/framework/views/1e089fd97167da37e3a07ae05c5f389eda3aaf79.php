

<?php $__env->startSection('title'); ?>
    Mata Kuliah
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Mata Kuliah</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dosen.matakuliah.form', [])->html();
} elseif ($_instance->childHasBeenRendered('rhNfNTd')) {
    $componentId = $_instance->getRenderedChildComponentId('rhNfNTd');
    $componentTag = $_instance->getRenderedChildComponentTagName('rhNfNTd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rhNfNTd');
} else {
    $response = \Livewire\Livewire::mount('dosen.matakuliah.form', []);
    $html = $response->html();
    $_instance->logRenderedChild('rhNfNTd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dosen.matakuliah.index', [])->html();
} elseif ($_instance->childHasBeenRendered('6kG4HvV')) {
    $componentId = $_instance->getRenderedChildComponentId('6kG4HvV');
    $componentTag = $_instance->getRenderedChildComponentTagName('6kG4HvV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6kG4HvV');
} else {
    $response = \Livewire\Livewire::mount('dosen.matakuliah.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('6kG4HvV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        window.addEventListener('backTop', () => {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smart-presensi\resources\views/dosen/matakuliah.blade.php ENDPATH**/ ?>