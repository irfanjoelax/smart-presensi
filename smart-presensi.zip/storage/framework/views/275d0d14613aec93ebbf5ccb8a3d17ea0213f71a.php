

<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1 class="display-1 mb-3">
            <i class="fas fa-qrcode"></i>
        </h1>
        <h1 class="display-5 fw-bold">Halaman Dashboard</h1>
        <h5 class="text-muted">Daftar presensi mata kuliah kamu.</h5>
    </div>
    <div class="row mt-3">
        <div class="col-12 mb-3">
            <?php $__currentLoopData = $presensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white shadow p-3 rounded">
                    <h5 class="fw-bold"><?php echo e($presensi->pertemuan->matakuliah->nama); ?></h5>
                    <h6 class="text-muted"><?php echo e($presensi->pertemuan->matakuliah->user->name); ?></h6>
                    <div class="d-flex align-items-center justify-content-between mt-3">
                        <span class="d-flex align-items-center gap-2 text-success">
                            <i class="fas fa-calendar-alt"></i>
                            <small>Pertemuan ke-<?php echo e($presensi->pertemuan->urutan); ?></small>
                        </span>
                        <span class="d-flex align-items-center gap-2 text-danger">
                            <i class="fas fa-clock"></i>
                            <small><?php echo e(substr($presensi->created_at, 11, 8)); ?></small>
                        </span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smart-presensi\resources\views/mahasiswa/dashboard.blade.php ENDPATH**/ ?>