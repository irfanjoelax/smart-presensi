<form class="form-inline" wire:submit.prevent="submit">
    <div class="input-group mb-2 mr-sm-2">
        <div class="input-group-prepend">
            <div class="input-group-text">Mata Kuliah</div>
        </div>
        <select class="form-control <?php $__errorArgs = ['matakuliah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="matakuliah_id">
            <option value="" selected>-- BELUM DIPILIH --</option>
            <?php $__currentLoopData = $matakuliahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($matakuliah->id); ?>"><?php echo e($matakuliah->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="input-group mb-2 mr-sm-2">
        <div class="input-group-prepend">
            <div class="input-group-text">Pertemuan</div>
        </div>
        <select class="form-control <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="urutan">
            <option value="" selected>-- BELUM DIPILIH --</option>
            <?php if($matakuliah_id != null): ?>
                <?php for($i = 1; $i <= 14; $i++): ?>
                    <option value="<?php echo e($i); ?>">Pertemuan ke: <?php echo e($i); ?></option>
                <?php endfor; ?>
            <?php endif; ?>
        </select>
    </div>

    <button type="submit" class="btn btn-dark mb-2">
        <div wire:loading wire:target="submit">
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
        </div>
        <small>Submit</small>
    </button>
</form>
<?php /**PATH C:\laragon\www\smart-presensi\resources\views/livewire/dosen/presensi/form.blade.php ENDPATH**/ ?>