

<?php $__env->startSection('title'); ?>
    Presensi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1 class="display-1 mb-3">
            <i class="fas fa-clipboard-list"></i>
        </h1>
        <h1 class="display-5 fw-bold">Halaman Presensi</h1>
        <h5 class="text-muted">Pastikan mata kuliah dan pertemuannya sudah benar.</h5>
    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mahasiswa.presensi', ['idPertemuan' => $id_pertemuan,'matakuliahId' => $matakuliah_id,'id_pertemuan' => $id_pertemuan,'matakuliah_id' => $matakuliah_id,'urutan' => $urutan])->html();
} elseif ($_instance->childHasBeenRendered('Cw1hO79')) {
    $componentId = $_instance->getRenderedChildComponentId('Cw1hO79');
    $componentTag = $_instance->getRenderedChildComponentTagName('Cw1hO79');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Cw1hO79');
} else {
    $response = \Livewire\Livewire::mount('mahasiswa.presensi', ['idPertemuan' => $id_pertemuan,'matakuliahId' => $matakuliah_id,'id_pertemuan' => $id_pertemuan,'matakuliah_id' => $matakuliah_id,'urutan' => $urutan]);
    $html = $response->html();
    $_instance->logRenderedChild('Cw1hO79', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smart-presensi\resources\views/mahasiswa/presensi.blade.php ENDPATH**/ ?>