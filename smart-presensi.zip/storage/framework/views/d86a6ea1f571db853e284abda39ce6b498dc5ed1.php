<div class="row">
    <div class="col-md-5">
        <form class="card rounded shadow p-3" wire:submit.prevent="submit">
            <div class="form-group mb-3">
                <label>Mata Kuliah</label>
                <select class="form-control <?php $__errorArgs = ['matakuliah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="matakuliah_id">
                    <option value="" selected>-- BELUM DIPILIH --</option>
                    <?php $__currentLoopData = $matakuliahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($matakuliah->id); ?>"><?php echo e($matakuliah->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['matakuliah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mb-3">
                <label>Pertemuan</label>
                <select class="form-control <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="urutan">
                    <option value="" selected>-- BELUM DIPILIH --</option>
                    <?php if($matakuliah_id != null): ?>
                        <?php for($i = 1; $i <= 14; $i++): ?>
                            <option value="<?php echo e($i); ?>">Pertemuan ke: <?php echo e($i); ?></option>
                        <?php endfor; ?>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <button type="submit" class="btn btn-dark">
                    <div wire:loading wire:target="submit">
                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    </div>
                    <small>Generate</small>
                </button>
                <?php if($kunci != null): ?>
                    <button type="button" wire:click="resetForm" class="btn btn-warning ml-2">
                        <div wire:loading wire:target="resetForm">
                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                        </div>
                        <small>Reset</small>
                    </button>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="col-md-7">
        <div class="card rounded shadow p-3">
            <p class="h5 text-center">
                Tersisa: <strong class="text-primary"><?php echo e($tersisa); ?></strong> Mahasiswa
            </p>
            <?php if($kunci != null): ?>
                <div class="m-auto text-center pt-4">
                    
                    <?php echo QrCode::size(300)->generate(
                        'http://192.168.152.87/smart-presensi/public/mahasiswa/presensi/' . $matakuliah_id . '/' . $urutan . '/' . $kunci,
                    ); ?>

                    <p class="mt-3">
                        <small>Scan QR code untuk melakukan presensi</small>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\smart-presensi\resources\views/livewire/dosen/generate.blade.php ENDPATH**/ ?>