

<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1 class="display-1 mb-3">
            <i class="fas fa-user-cog"></i>
        </h1>
        <h1 class="display-5 fw-bold">
            Halaman Profile
        </h1>
        <h5 class="text-muted">Atur profile dan data diri kamu disini.</h5>
    </div>
    <div class="row mt-4">
        <div class="col-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mahasiswa.profile', [])->html();
} elseif ($_instance->childHasBeenRendered('2ZO8N6c')) {
    $componentId = $_instance->getRenderedChildComponentId('2ZO8N6c');
    $componentTag = $_instance->getRenderedChildComponentTagName('2ZO8N6c');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2ZO8N6c');
} else {
    $response = \Livewire\Livewire::mount('mahasiswa.profile', []);
    $html = $response->html();
    $_instance->logRenderedChild('2ZO8N6c', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col">
            <a href="<?php echo e(route('logout')); ?>"
                class="btn btn-lg btn-outline-danger d-flex gap-2 align-items-center justify-content-center"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i>
                <span>Keluar Aplikasi</span>
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smart-presensi\resources\views/mahasiswa/profile.blade.php ENDPATH**/ ?>