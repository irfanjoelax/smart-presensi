

<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-4 col-12">
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3><?php echo e($totalMatakuliah); ?></h3>
                    <p>Mata Kuliah</p>
                </div>
                <div class="icon">
                    <i class="fas fa-book"></i>
                </div>
                <a href="<?php echo e(url('/dosen/matakuliah')); ?>" class="small-box-footer">
                    Selengkapnya <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-4 col-12">
            <div class="small-box bg-light">
                <div class="inner">
                    <h3>Cek</h3>
                    <p>Daftar Presensi</p>
                </div>
                <div class="icon">
                    <i class="far fa-address-book"></i>
                </div>
                <a href="<?php echo e(url('/dosen/presensi')); ?>" class="small-box-footer">
                    Selengkapnya <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-4 col-12">
            <div class="small-box bg-secondary">
                <div class="inner">
                    <h3>QR</h3>
                    <p>Generate Sekarang</p>
                </div>
                <div class="icon">
                    <i class="fas fa-qrcode"></i>
                </div>
                <a href="<?php echo e(url('/dosen/generate-qr')); ?>" class="small-box-footer">
                    Selengkapnya <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smart-presensi\resources\views/dosen/dashboard.blade.php ENDPATH**/ ?>