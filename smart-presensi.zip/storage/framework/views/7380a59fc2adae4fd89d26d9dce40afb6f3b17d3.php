<div class="table-responsive bg-white p-3 shadow rounded">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Lengkap</th>
                <th scope="col">NIM</th>
                <th scope="col">Waktu Hadir</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $presensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row">
                        <?php echo e($loop->iteration); ?>

                    </th>
                    <td><?php echo e($item->user->name); ?></td>
                    <td><?php echo e($item->user->no_induk); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-danger">
                        Pilih mata kuliah dan pertemuan untuk melihat data presensi
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\laragon\www\smart-presensi\resources\views/livewire/dosen/presensi/table.blade.php ENDPATH**/ ?>