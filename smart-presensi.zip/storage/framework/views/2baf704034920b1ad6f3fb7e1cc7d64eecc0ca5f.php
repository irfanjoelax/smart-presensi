<div>
    <p class="h5 text-center">
        Tersisa: <strong class="text-primary"><?php echo e($tersisa); ?></strong> Mahasiswa
    </p>
</div>
<?php /**PATH C:\laragon\www\smart-presensi\resources\views/livewire/dosen/kuota.blade.php ENDPATH**/ ?>