<?php return array (
  'dosen.generate' => 'App\\Http\\Livewire\\Dosen\\Generate',
  'dosen.kuota' => 'App\\Http\\Livewire\\Dosen\\Kuota',
  'dosen.matakuliah.form' => 'App\\Http\\Livewire\\Dosen\\Matakuliah\\Form',
  'dosen.matakuliah.index' => 'App\\Http\\Livewire\\Dosen\\Matakuliah\\Index',
  'dosen.presensi.form' => 'App\\Http\\Livewire\\Dosen\\Presensi\\Form',
  'dosen.presensi.table' => 'App\\Http\\Livewire\\Dosen\\Presensi\\Table',
  'mahasiswa.presensi' => 'App\\Http\\Livewire\\Mahasiswa\\Presensi',
  'mahasiswa.profile' => 'App\\Http\\Livewire\\Mahasiswa\\Profile',
);